Base nueva de la rama de orientación.

Archivos principales:
- orientacion/orientacion.html
- orientacion/orientacion.css
- orientacion/orientacion-state.js
- orientacion/orientacion-utils.js
- orientacion/orientacion-map.js
- orientacion/orientacion-import.js
- orientacion/orientacion-generator.js
- orientacion/orientacion-app.js
- orientacion/orientacion-participant.html
- orientacion/orientacion-live.html

Esta base no toca la rama topográfica ni el index actual.
